//
// Created by Alejandro  Otero on 2019-08-31.
//


#ifndef AREA_COMPUESTA_CENTROIDE_H
#define AREA_COMPUESTA_CENTROIDE_H

#endif //AREA_COMPUESTA_CENTROIDE_H

class Centroide{
protected:
    float x,y;
public:
    Centroide(float,float);
    Centroide();
    virtual float centrox();
    virtual float centroy();
};

class Figura:public Centroide{
protected:
    float lado,ancho;
public:
    Figura(float, float,float,float);
    Figura();
    virtual float area();
    virtual float x();
    virtual float y();
    float centrox();
    float centroy();
};

class Triangulo:public Figura{
public:
    Triangulo(float,float,float, float);
    float area();
    float x();
    float y();
};

class Rectangulo:public Figura{
public:
    Rectangulo(float,float,float,float);

    float area();

    float x();

    float y();
};

class Circulo:public Figura{
private:
    float radio;
public:
    Circulo(float,float,float,float,float);

    float area();

    float x();

    float y();
};