//
// Created by Alejandro  Otero on 2019-08-31.
//
#include "centroide.h"
#include <cmath>

Centroide::Centroide(float _x,float _y){
    x=_x;
    y=_y;
}

Centroide::Centroide() {
}

Figura::Figura(float _x, float _y,float _lado,float _ancho):Centroide(_x,_y){
    lado=_lado;
    ancho=_ancho;
}

Figura::Figura(){

}

float Figura::centrox() {
    Rectangulo::area();
    Triangulo::area();
    Circulo::area();
}

float Figura::centroy() {
    Rectangulo::area();
    Triangulo::area();
    Circulo::area();
}

Rectangulo::Rectangulo(float _x,float _y,float _lado, float _ancho):Figura(_x,_y,_lado,_ancho) {}

Triangulo::Triangulo(float _x, float _y, float _lado, float _ancho):Figura(_x,_y,_lado,_ancho) {}

float Rectangulo::area() {
    return lado*ancho;
}

float Rectangulo::x() {
    return
}

float Rectangulo::y() {
    return lado/2;
}

float Triangulo::area() {
    return (lado*ancho)/2;
}

float Triangulo::x() {
    return (2.0/3.0)*ancho;
}

float Triangulo::y(){
    return (1.0/3.0)*lado;
}

Circulo::Circulo(float _x,float _y,float _lado, float _ancho,float r):Figura(_x,_y,_lado,_ancho) {
    radio=r;
}

float Circulo::area() {
    float pi=3.14;
    return pow(radio,2)*pi;
}

float Circulo::x() {
    return (ancho/2);
}

float Circulo::y(){
    return lado/2;
}